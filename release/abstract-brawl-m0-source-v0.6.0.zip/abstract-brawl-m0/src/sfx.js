/* 音效：WebAudio 程序化合成，无外部音频文件。 */
(function () {
  'use strict';
  var FG = window.FG;
  var ac = null;

  function context() {
    if (!ac) {
      try { ac = new (window.AudioContext || window.webkitAudioContext)(); } catch (e) { ac = null; }
    }
    if (ac && ac.state === 'suspended') ac.resume();
    return ac;
  }

  function tone(f, dur, type, vol, slide) {
    var a = context();
    if (!a) return;
    var t0 = a.currentTime;
    var o = a.createOscillator(), g = a.createGain();
    o.type = type;
    o.frequency.setValueAtTime(f, t0);
    if (slide) o.frequency.linearRampToValueAtTime(Math.max(30, f + slide), t0 + dur);
    g.gain.setValueAtTime(vol, t0);
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    o.connect(g);
    g.connect(a.destination);
    o.start(t0);
    o.stop(t0 + dur + 0.03);
  }

  function noise(dur, vol) {
    var a = context();
    if (!a) return;
    var n = Math.floor(a.sampleRate * dur);
    var buf = a.createBuffer(1, n, a.sampleRate), d = buf.getChannelData(0);
    for (var i = 0; i < n; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / n);
    var src = a.createBufferSource(), g = a.createGain();
    src.buffer = buf;
    g.gain.value = vol;
    src.connect(g);
    g.connect(a.destination);
    src.start();
  }

  FG.sfx = {
    unlock: function () { context(); },
    play: function (type) {
      if (type === 'hit') { tone(220, 0.09, 'square', 0.11, -150); noise(0.06, 0.12); }
      else if (type === 'heavy') { tone(140, 0.18, 'square', 0.14, -90); noise(0.12, 0.2); }
      else if (type === 'block') tone(520, 0.06, 'triangle', 0.1, 120);
      else if (type === 'ko') { tone(160, 0.8, 'sawtooth', 0.14, -120); noise(0.4, 0.18); }
      else if (type === 'fight') { tone(523, 0.12, 'triangle', 0.1); setTimeout(function () { tone(784, 0.2, 'triangle', 0.1); }, 110); }
      else if (type === 'super') { tone(300, 0.5, 'sawtooth', 0.09, 600); tone(150, 0.5, 'square', 0.06, 300); }
      else if (type === 'jump') tone(330, 0.08, 'sine', 0.06, 200);
      else if (type === 'land') noise(0.05, 0.06);
      else if (type === 'dash' || type === 'bdash') noise(0.08, 0.07);
      else if (type === 'tech') tone(660, 0.08, 'triangle', 0.08, -200);
      else if (type === 'gc') { tone(880, 0.12, 'triangle', 0.1, -400); noise(0.08, 0.1); }
      else if (type === 'throw') { tone(120, 0.22, 'square', 0.13, -60); noise(0.15, 0.18); }
      else if (type === 'throwbreak') tone(1040, 0.1, 'square', 0.08, -300);
    }
  };
})();
