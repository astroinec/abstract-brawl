/* 应用层：标题 / 选角 / 对战 / 暂停 / 结算 / 闯关（对白、续关、结局）/ 说明，以及固定 60Hz 的主循环。 */
(function () {
  'use strict';
  var FG = window.FG;
  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');
  // 高分屏按设备像素比放大画布，文字更清晰；逻辑坐标仍是 960x540
  var dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = FG.W * dpr;
  canvas.height = FG.H * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  var ORDER = ['frog', 'roo'];

  var MODES = [
    { id: 'cpu', label: '单机 · 对战电脑' },
    { id: 'training', label: '训练模式' },
    { id: 'pvp', label: '本地双人' },
    { id: 'arcade', label: '闯关模式' },
    { id: 'help', label: '操作说明' }
  ];
  var PAUSE_ITEMS = [{ label: '继续' }, { label: '重新开始' }, { label: '返回标题' }];
  var RESULT_ITEMS = [{ label: '再来一局' }, { label: '返回标题' }];
  var CONTINUE_ITEMS = [{ label: '继续挑战' }, { label: '返回标题' }];

  var view = {
    screen: 'title', items: MODES, index: 0, tick: 0,
    mode: 'cpu', pick: 0, diff: 2, match: null, ai: null, mirror: false,
    showHitbox: false, dummyMode: 0, dummyState: FG.ai.newAI(1),
    trk: FG.trainer.create(),
    arc: null,
    lag: [1000, 1000], fxs: FG.fx.create(), cam: { x: 0, zoom: 1 }, slowAcc: 0
  };

  function setScreen(name) {
    view.screen = name;
    view.index = 0;
    if (name === 'fight') FG.input.clearTaps();   // 菜单里的按键不能带进对战
    if (name === 'title') view.items = MODES;
    else if (name === 'pause') view.items = PAUSE_ITEMS;
    else if (name === 'result') view.items = RESULT_ITEMS;
    else if (name === 'continue') view.items = CONTINUE_ITEMS;
    else view.items = [];
  }

  function freshMatch(opts, level) {
    view.match = FG.sim.createMatch(opts);
    view.ai = FG.ai.newAI(level);
    view.dummyState = FG.ai.newAI(1);
    view.lag = [view.match.p[0].health, view.match.p[1].health];
    view.fxs = FG.fx.create();
    view.cam = { x: 0, zoom: 1 };
    var keep = view.trk.rec;   // 重新开始时保留训练录像
    view.trk = FG.trainer.create();
    view.trk.rec = keep;
    keep.mode = 'off';
    setScreen('fight');
  }

  function startMatch() {
    if (view.mode === 'arcade') {
      var sm = FG.arcade.stageMatch(view.arc.fid, view.arc.stage);
      view.mirror = sm.mirror;
      freshMatch({ mode: 'cpu', fid0: sm.fid0, fid1: sm.fid1, name1: sm.name1, seed: Date.now() >>> 0 }, sm.level);
      return;
    }
    var p1 = ORDER[view.pick], p2 = ORDER[1 - view.pick];
    view.mirror = false;
    freshMatch({ mode: view.mode, fid0: p1, fid1: p2, seed: Date.now() >>> 0 }, view.diff);
  }

  // ---------------- 闯关流程 ----------------
  function startArcade() {
    view.arc = { fid: ORDER[view.pick], stage: 0, line: 0, continues: 0, startTick: view.tick };
    setScreen('story');
  }

  function arcadeAfterMatch() {
    var m = view.match, A = view.arc;
    if (m.matchWinner === 0) {
      A.stage++;
      A.line = 0;
      if (A.stage >= FG.arcade.STAGES.length) { A.endTick = view.tick; setScreen('ending'); }
      else setScreen('story');
    } else {
      setScreen('continue');
    }
  }

  function fightStep() {
    var m = view.match;
    var s = FG.input.sample();
    var p1 = s[0], p2 = s[1];
    if (view.mode === 'cpu' || view.mode === 'arcade') {
      p2 = FG.ai.cpuDecide(m, m.p[1], m.p[0], view.ai);
    } else if (view.mode === 'training') {
      var dummy = FG.ai.dummyDecide(m, m.p[1], m.p[0], FG.ai.DUMMY_MODES[view.dummyMode], view.dummyState);
      var routed = FG.trainer.route(view.trk, p1, dummy);
      p1 = routed[0]; p2 = routed[1];
    }
    FG.sim.step(m, [p1, p2]);
    if (view.mode === 'training') FG.trainer.observe(view.trk, m);
    for (var i = 0; i < m.events.length; i++) {
      var e = m.events[i];
      FG.sfx.play(e.type === 'hit' && (e.heavy || e.kd) ? 'heavy' : e.type);
    }
    FG.fx.onEvents(view.fxs, m, m.events);
    if (m.phase === 'matchEnd') {
      if (view.mode === 'arcade') arcadeAfterMatch();
      else setScreen('result');
    }
  }

  function cycle(n, d) { return (view.index + n + d) % n; }

  function handleActions() {
    var acts = FG.input.actions();
    if (!acts.length) return;
    FG.sfx.unlock();
    for (var i = 0; i < acts.length; i++) {
      var a = acts[i];
      var sc = view.screen;
      if (sc === 'title') {
        if (a === 'up') view.index = cycle(MODES.length, -1);
        else if (a === 'down') view.index = cycle(MODES.length, 1);
        else if (a === 'ok') {
          var it = MODES[view.index];
          if (it.id === 'help') setScreen('help');
          else { view.mode = it.id; view.pick = 0; setScreen('select'); }
        }
      } else if (sc === 'select') {
        var hasDiff = view.mode === 'cpu';   // 闯关每关难度固定（简单 → 普通 → 困难）
        if (a === 'left' || a === 'right') view.pick = (view.pick + 1) % ORDER.length;
        else if ((a === 'up' || a === 'down') && hasDiff) view.diff = FG.clamp(view.diff + (a === 'up' ? 1 : -1), 1, 3);
        else if (a === 'up' || a === 'down') view.pick = (view.pick + 1) % ORDER.length;
        else if (a === 'ok') { if (view.mode === 'arcade') startArcade(); else startMatch(); }
        else if (a === 'back' || a === 'escape') setScreen('title');
      } else if (sc === 'fight') {
        var tr = view.mode === 'training';
        if (a === 'escape') setScreen('pause');
        else if (a === 'hitbox') view.showHitbox = !view.showHitbox;
        else if (tr && a === 'reset') { FG.sim.resetRound(view.match); view.trk.rec.idx = 0; }
        else if (tr && a === 'dummy') view.dummyMode = (view.dummyMode + 1) % FG.ai.DUMMY_MODES.length;
        else if (tr && a === 'infinite') view.match.infinite = !view.match.infinite;
        else if (tr && a === 'record') { FG.sim.resetRound(view.match); FG.trainer.toggleRecord(view.trk); }
        else if (tr && a === 'play') { FG.sim.resetRound(view.match); FG.trainer.togglePlay(view.trk); }
      } else if (sc === 'pause') {
        if (a === 'up') view.index = cycle(PAUSE_ITEMS.length, -1);
        else if (a === 'down') view.index = cycle(PAUSE_ITEMS.length, 1);
        else if (a === 'ok') {
          if (view.index === 0) setScreen('fight');
          else if (view.index === 1) startMatch();
          else setScreen('title');
        } else if (a === 'escape' || a === 'back') setScreen('fight');
      } else if (sc === 'result') {
        if (a === 'up' || a === 'down') view.index = (view.index + 1) % RESULT_ITEMS.length;
        else if (a === 'ok') {
          if (view.index === 0) startMatch();
          else setScreen('title');
        } else if (a === 'escape' || a === 'back') setScreen('title');
      } else if (sc === 'story') {
        if (a === 'ok') {
          var lines = FG.arcade.LINES[view.arc.fid][view.arc.stage];
          view.arc.line++;
          if (view.arc.line >= lines.length) startMatch();
        } else if (a === 'escape' || a === 'back') setScreen('title');
      } else if (sc === 'continue') {
        if (a === 'up' || a === 'down') view.index = (view.index + 1) % CONTINUE_ITEMS.length;
        else if (a === 'ok') {
          if (view.index === 0) { view.arc.continues++; view.arc.line = 0; setScreen('story'); }
          else setScreen('title');
        } else if (a === 'escape' || a === 'back') setScreen('title');
      } else if (sc === 'ending') {
        if (a === 'ok' || a === 'escape' || a === 'back') setScreen('title');
      } else if (sc === 'help') {
        if (a === 'ok' || a === 'escape' || a === 'back') setScreen('title');
      }
    }
  }

  function updateFx() {
    if (view.screen === 'fight') {
      FG.fx.update(view.fxs, view.match, view.tick);
      FG.render.updateCamera(view.cam, view.match, view.fxs);
    }
    if (view.match) {
      for (var j = 0; j < 2; j++) {
        var hp = view.match.p[j].health;
        if (view.lag[j] > hp) view.lag[j] = Math.max(hp, view.lag[j] - 4);
        else view.lag[j] = hp;
      }
    }
  }

  var last = 0, acc = 0, STEP = 1 / 60;
  function frame(ts) {
    if (!last) last = ts;
    var dt = Math.min(0.1, (ts - last) / 1000);
    last = ts;
    view.tick++;
    handleActions();
    if (view.screen !== 'fight') FG.input.clearTaps();
    if (view.screen === 'fight') {
      acc += dt;
      while (acc >= STEP && view.screen === 'fight') {
        acc -= STEP;
        // KO 慢动作：只放慢表现节奏，逻辑帧本身不变
        if (view.fxs.slow > 0) {
          view.slowAcc = (view.slowAcc + 1) % 2;
          if (view.slowAcc) continue;
        }
        fightStep();
      }
      if (view.screen !== 'fight') acc = 0;
    } else {
      acc = 0;
    }
    updateFx();
    FG.render.draw(ctx, view);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  FG.app = { view: view, startMatch: startMatch, setScreen: setScreen, startArcade: startArcade, arcadeAfterMatch: arcadeAfterMatch };
})();
