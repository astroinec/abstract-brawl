/* 画面：镜头、舞台、角色精灵、弹道、HUD、各界面。纯表现层。 */
(function () {
  'use strict';
  var FG = window.FG;
  var W = FG.W, H = FG.H, G = FG.GROUND_Y, SUB = FG.SUB;
  var TAU = Math.PI * 2;
  var FONT = FG.fx.FONT;
  var OT = FG.fx.outlineText;
  var ORDER = ['frog', 'roo'];
  var MODE_NAMES = { cpu: '单机 · 对战电脑', training: '训练模式', pvp: '本地双人', arcade: '闯关模式' };
  var DARK_FILTER = 'brightness(0.6) saturate(1.6) hue-rotate(250deg)';

  function X(wx) { return W / 2 + wx / SUB; }
  function Y(wy) { return G - wy / SUB; }

  function text(ctx, s, x, y, size, color, align, weight) {
    ctx.font = (weight ? weight + ' ' : '') + size + 'px ' + FONT;
    ctx.fillStyle = color;
    ctx.textAlign = align || 'left';
    ctx.textBaseline = 'middle';
    ctx.fillText(s, x, y);
  }

  function rr(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }

  // 平行四边形（血条形状）；slant > 0 向右倾
  function para(ctx, x, y, w, h, slant) {
    ctx.beginPath();
    ctx.moveTo(x + slant, y);
    ctx.lineTo(x + w + slant, y);
    ctx.lineTo(x + w, y + h);
    ctx.lineTo(x, y + h);
    ctx.closePath();
  }

  // ---------------- 镜头 ----------------
  function updateCamera(cam, m, S) {
    var a = m.p[0], b = m.p[1];
    var mid = (a.x + b.x) / 2 / SUB;
    var d = Math.abs(a.x - b.x) / SUB;
    var tz = FG.clamp(1.22 - (d - 120) / 900, 1, 1.18);
    if (S && S.superCut) {
      mid = m.p[S.superCut.p].x / SUB;
      tz = 1.32;
    }
    if (S && S.kick) tz += S.kick;   // 重击瞬间镜头推近
    cam.zoom += (tz - cam.zoom) * (S && S.kick > 0.01 ? 0.35 : 0.12);
    var lim = W / 2 - W / 2 / cam.zoom;
    var tx = FG.clamp(mid, -lim, lim);
    cam.x += (tx - cam.x) * 0.15;
    cam.x = FG.clamp(cam.x, -lim, lim);
  }

  function worldTransform(ctx, cam, shakeX, shakeY) {
    ctx.translate(W / 2 + shakeX, G + shakeY);
    ctx.scale(cam.zoom, cam.zoom);
    ctx.translate(-W / 2 - cam.x, -G);
  }

  // ---------------- 世界绘制 ----------------
  function shadow(ctx, p) {
    var s = Math.max(0.35, 1 - (p.y / SUB) / 260);
    var w = p.fid === 'roo' ? 64 : 54;
    ctx.fillStyle = 'rgba(0,0,0,0.38)';
    ctx.beginPath();
    ctx.ellipse(X(p.x), G + 3, w * s, 10 * s, 0, 0, TAU);
    ctx.fill();
  }

  function fighter(ctx, m, p, t, view) {
    shadow(ctx, p);
    if (FG.sprites.ready(p.fid)) {
      var pose = FG.sprites.poseOf(m, p, t, view.fxs);
      if (view.mirror && p.idx === 1) pose.filter = DARK_FILTER;
      if (view.fxs.superCut && view.fxs.superCut.p === p.idx) {
        ctx.save();
        ctx.shadowColor = FG.FIGHTERS[p.fid].color;
        ctx.shadowBlur = 30;
        FG.sprites.drawSprite(ctx, p.fid, pose.key, X(p.x), Y(p.y), p.facing, pose);
        ctx.restore();
      } else {
        FG.sprites.drawSprite(ctx, p.fid, pose.key, X(p.x), Y(p.y), p.facing, pose);
      }
    } else {
      FG.art.drawCreature(ctx, p.fid, X(p.x), Y(p.y), FG.art.poseOf(p, t));
    }
  }

  function drawTongue(ctx, pr, owner, t) {
    var x = X(pr.x), y = Y(pr.y);
    var mo = FG.sprites.DEFS.frog.mouth;
    var mx = X(owner.x) + owner.facing * mo[0], my = Y(owner.y) - mo[1];
    var attached = owner.state === 'atk' && owner.mv === '236A';
    ctx.save();
    ctx.lineCap = 'round';
    if (attached) {
      var cy = my - 18 + Math.sin(t / 2) * 6;
      ctx.strokeStyle = '#b2405f';
      ctx.lineWidth = 16;
      ctx.beginPath(); ctx.moveTo(mx, my); ctx.quadraticCurveTo((mx + x) / 2, cy, x, y); ctx.stroke();
      ctx.strokeStyle = '#ff8fb1';
      ctx.lineWidth = 11;
      ctx.beginPath(); ctx.moveTo(mx, my); ctx.quadraticCurveTo((mx + x) / 2, cy, x, y); ctx.stroke();
      ctx.strokeStyle = 'rgba(255,255,255,0.45)';
      ctx.lineWidth = 3;
      ctx.beginPath(); ctx.moveTo(mx, my - 3); ctx.quadraticCurveTo((mx + x) / 2, cy - 4, x, y - 3); ctx.stroke();
    } else {
      ctx.strokeStyle = 'rgba(255,143,177,0.4)';
      ctx.lineWidth = 6;
      ctx.beginPath(); ctx.moveTo(x - pr.vx / SUB * 6, y); ctx.lineTo(x, y); ctx.stroke();
    }
    ctx.fillStyle = '#ff6f9c';
    ctx.strokeStyle = '#8a2240';
    ctx.lineWidth = 2.5;
    ctx.beginPath(); ctx.ellipse(x, y, 17, 13, 0, 0, TAU); ctx.fill(); ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,0.6)';
    ctx.beginPath(); ctx.ellipse(x - 5, y - 5, 5, 3, -0.4, 0, TAU); ctx.fill();
    ctx.restore();
  }

  function drawCuffs(ctx, pr, t) {
    var x = X(pr.x), y = Y(pr.y);
    var dir = pr.vx > 0 ? 1 : -1;
    ctx.save();
    for (var k = 1; k <= 3; k++) {
      ctx.globalAlpha = 0.18 / k;
      ctx.fillStyle = '#dfe8ff';
      ctx.beginPath(); ctx.arc(x - dir * k * 14, y, 20, 0, TAU); ctx.fill();
    }
    ctx.globalAlpha = 1;
    ctx.translate(x, y);
    ctx.rotate(t * 0.35 * dir);
    ctx.lineWidth = 6;
    ctx.strokeStyle = '#4b5568';
    ctx.beginPath(); ctx.arc(-13, 0, 12, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.arc(13, 0, 12, 0, TAU); ctx.stroke();
    ctx.lineWidth = 3.5;
    ctx.strokeStyle = '#d6deea';
    ctx.beginPath(); ctx.arc(-13, 0, 12, 0, TAU); ctx.stroke();
    ctx.beginPath(); ctx.arc(13, 0, 12, 0, TAU); ctx.stroke();
    ctx.strokeStyle = '#aab4c6';
    ctx.lineWidth = 3;
    ctx.beginPath(); ctx.moveTo(-2, 0); ctx.lineTo(2, 0); ctx.stroke();
    ctx.restore();
  }

  function box(ctx, r, stroke, fill) {
    var l = X(r[0]), rt = X(r[2]), top = Y(r[3]), bot = Y(r[1]);
    ctx.fillStyle = fill;
    ctx.fillRect(l, top, rt - l, bot - top);
    ctx.strokeStyle = stroke;
    ctx.lineWidth = 1.5;
    ctx.strokeRect(l, top, rt - l, bot - top);
  }

  function debugBoxes(ctx, m) {
    for (var i = 0; i < 2; i++) {
      var p = m.p[i];
      var hr = FG.sim.hurtRect(p);
      if (hr) box(ctx, hr, 'rgba(120,180,255,1)', 'rgba(120,180,255,0.16)');
      if (p.state === 'atk' && p.mv) {
        var hits = p.moves[p.mv].hits;
        for (var k = 0; k < hits.length; k++) {
          var h = hits[k];
          if (p.mf >= h.f1 && p.mf <= h.f2) box(ctx, FG.sim.worldBox(p, h.box), '#ff4d6d', 'rgba(255,77,109,0.35)');
        }
      }
    }
    m.proj.forEach(function (pr) {
      var hw = Math.floor(pr.w / 2), hh = Math.floor(pr.h / 2);
      box(ctx, [pr.x - hw, pr.y - hh, pr.x + hw, pr.y + hh], '#ff4d6d', 'rgba(255,77,109,0.35)');
    });
  }

  function drawWorld(ctx, view, t) {
    var m = view.match, S = view.fxs;
    FG.fx.drawWorldBack(ctx, S);
    FG.fx.drawGhosts(ctx, S);
    // 被攻击方先画，攻击方压在上面
    var order = (m.p[0].state === 'atk' && m.p[1].state !== 'atk') ? [1, 0] : [0, 1];
    fighter(ctx, m, m.p[order[0]], t, view);
    fighter(ctx, m, m.p[order[1]], t, view);
    for (var i = 0; i < m.proj.length; i++) {
      var pr = m.proj[i], owner = m.p[pr.owner];
      if (owner.fid === 'frog') drawTongue(ctx, pr, owner, t); else drawCuffs(ctx, pr, t);
    }
    FG.fx.drawWorldFront(ctx, S, m);
    if (view.showHitbox) debugBoxes(ctx, m);
    FG.fx.drawNumbersAndCaptions(ctx, S, m);
  }

  // ---------------- HUD ----------------
  function portraitRing(ctx, fid, x, y, r, mirror, color) {
    ctx.save();
    ctx.fillStyle = '#1a1026';
    ctx.beginPath(); ctx.arc(x, y, r + 5, 0, TAU); ctx.fill();
    if (!FG.sprites.drawPortrait(ctx, fid, x, y, r, mirror)) {
      ctx.fillStyle = FG.FIGHTERS[fid].color;
      ctx.beginPath(); ctx.arc(x, y, r, 0, TAU); ctx.fill();
    }
    ctx.lineWidth = 4;
    ctx.strokeStyle = color;
    ctx.beginPath(); ctx.arc(x, y, r + 2, 0, TAU); ctx.stroke();
    ctx.restore();
  }

  function healthBar(ctx, m, i, lag, t) {
    var p = m.p[i], F = FG.FIGHTERS[p.fid];
    var left = i === 0;
    var bw = 330, bh = 22, by = 30, sl = 12;
    var bx = left ? 96 : W - 96 - bw;
    var r = Math.max(0, p.health / p.maxHealth), lr = FG.clamp(lag / p.maxHealth, 0, 1);
    ctx.save();
    para(ctx, bx - 4, by - 4, bw + 8, bh + 8, left ? -sl : sl);
    ctx.fillStyle = 'rgba(10,6,20,0.85)';
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255,255,255,0.35)';
    ctx.stroke();
    para(ctx, bx, by, bw, bh, left ? -sl : sl);
    ctx.clip();
    ctx.fillStyle = '#2b1a33';
    ctx.fillRect(bx - 20, by, bw + 40, bh);
    // 余伤（红色，缓慢跟随）
    var lw = bw * lr;
    ctx.fillStyle = '#ff4d4d';
    if (left) ctx.fillRect(bx + bw - lw, by, lw + 20, bh); else ctx.fillRect(bx - 20, by, lw + 20, bh);
    var hw = bw * r;
    var g = ctx.createLinearGradient(0, by, 0, by + bh);
    if (r < 0.3) {
      var pulse = 0.5 + 0.5 * Math.sin(t / 5);
      g.addColorStop(0, 'rgb(255,' + Math.round(120 + 60 * pulse) + ',90)');
      g.addColorStop(1, '#d12f2f');
    } else {
      g.addColorStop(0, '#fff3a0');
      g.addColorStop(0.45, F.color);
      g.addColorStop(1, F.accent);
    }
    ctx.fillStyle = g;
    if (left) ctx.fillRect(bx + bw - hw, by, hw + 20, bh); else ctx.fillRect(bx - 20, by, hw + 20, bh);
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.fillRect(bx - 20, by + 2, bw + 40, 4);
    ctx.restore();
    var px0 = left ? 52 : W - 52;
    portraitRing(ctx, p.fid, px0, 46, 34, !left, F.color);
    OT(ctx, p.name, left ? bx + 4 : bx + bw - 4, by + bh + 17, 17, '#ffffff', '#120a1c', 4, left ? 'left' : 'right');
    for (var k = 0; k < m.maxWins; k++) {
      var sx = left ? bx + bw - 10 - k * 22 : bx + 10 + k * 22;
      var on = k < m.wins[i];
      ctx.save();
      ctx.translate(sx, by + bh + 16);
      ctx.beginPath();
      for (var s = 0; s < 10; s++) {
        var a = -Math.PI / 2 + s * Math.PI / 5, rad = s % 2 ? 4 : 9;
        ctx.lineTo(Math.cos(a) * rad, Math.sin(a) * rad);
      }
      ctx.closePath();
      ctx.fillStyle = on ? '#ffd23f' : 'rgba(255,255,255,0.15)';
      ctx.fill();
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = on ? '#7a4a00' : 'rgba(255,255,255,0.3)';
      ctx.stroke();
      ctx.restore();
    }
  }

  function powerGauge(ctx, p, i, t) {
    var left = i === 0;
    var segW = 62, gap = 5, bh = 12, by = H - 30;
    var total = segW * 3 + gap * 2;
    var bx = left ? 70 : W - 70 - total;
    var lvl = Math.floor(p.power / 100);
    ctx.save();
    ctx.fillStyle = 'rgba(10,6,20,0.8)';
    rr(ctx, bx - 52, by - 9, total + 60, bh + 18, 8);
    ctx.fill();
    for (var s = 0; s < 3; s++) {
      var sx0 = bx + s * (segW + gap);
      var fill = FG.clamp((p.power - s * 100) / 100, 0, 1);
      ctx.fillStyle = 'rgba(255,255,255,0.12)';
      para(ctx, sx0, by, segW, bh, 5);
      ctx.fill();
      if (fill > 0) {
        var full = fill >= 1;
        var g = ctx.createLinearGradient(sx0, 0, sx0 + segW, 0);
        g.addColorStop(0, full ? '#ffe14d' : '#5ad0ff');
        g.addColorStop(1, full ? '#ff8a00' : '#2a8cff');
        ctx.save();
        para(ctx, sx0, by, segW, bh, 5);
        ctx.clip();
        ctx.fillStyle = g;
        ctx.fillRect(sx0, by, (segW + 5) * fill, bh);
        if (full) {
          ctx.fillStyle = 'rgba(255,255,255,' + (0.25 + 0.25 * Math.sin(t / 6 + s)).toFixed(2) + ')';
          ctx.fillRect(sx0 + ((t * 3) % (segW + 30)) - 20, by, 14, bh);
        }
        ctx.restore();
      }
    }
    var lab = lvl >= 3 ? 'MAX' : 'Lv' + lvl;
    OT(ctx, lab, bx - 26, by + bh / 2, 15, lvl >= 1 ? '#ffe14d' : '#9fb3d9', '#120a1c', 4);
    ctx.restore();
  }

  function timerBadge(ctx, m, t) {
    var cx = W / 2, cy = 44;
    ctx.save();
    ctx.beginPath();
    for (var k = 0; k < 6; k++) {
      var a = k * Math.PI / 3 + Math.PI / 6;
      ctx.lineTo(cx + Math.cos(a) * 40, cy + Math.sin(a) * 36);
    }
    ctx.closePath();
    var g = ctx.createLinearGradient(0, cy - 36, 0, cy + 36);
    g.addColorStop(0, '#3a2160');
    g.addColorStop(1, '#140a26');
    ctx.fillStyle = g;
    ctx.fill();
    ctx.lineWidth = 3;
    ctx.strokeStyle = '#ffd23f';
    ctx.stroke();
    var secs = Math.max(0, Math.ceil(m.timer / 60));
    var ts = m.mode === 'training' ? '∞' : String(secs);
    var urgent = m.mode !== 'training' && secs <= 10 && m.phase === 'fight';
    OT(ctx, ts, cx, cy + 2, 34, urgent && Math.floor(t / 10) % 2 ? '#ff5d5d' : '#ffffff', '#000000', 5);
    ctx.restore();
    if (m.mode !== 'training') OT(ctx, '第 ' + m.round + ' 回合', cx, cy + 50, 13, '#e5d8ff', '#120a1c', 3);
  }

  function comboCounter(ctx, m, S) {
    for (var i = 0; i < 2; i++) {
      var a = m.p[i], d = m.p[1 - i];
      if (a.hitCount >= 2 && d.state === 'stun' && !d.blocked) {
        var pop = 1 + S.comboPop[i] * 0.45;
        ctx.save();
        ctx.translate(i === 0 ? 70 : W - 70, 190);
        ctx.scale(pop, pop);
        OT(ctx, String(a.hitCount), 0, 0, 58, '#ffe14d', '#3a0a00', 9);
        OT(ctx, '连击', 0, 40, 20, '#ffffff', '#3a0a00', 5);
        ctx.restore();
      }
    }
  }

  function hud(ctx, m, view, t) {
    var g = ctx.createLinearGradient(0, 0, 0, 110);
    g.addColorStop(0, 'rgba(8,4,16,0.6)');
    g.addColorStop(1, 'rgba(8,4,16,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, 110);
    healthBar(ctx, m, 0, view.lag[0], t);
    healthBar(ctx, m, 1, view.lag[1], t);
    timerBadge(ctx, m, t);
    powerGauge(ctx, m.p[0], 0, t);
    powerGauge(ctx, m.p[1], 1, t);
    comboCounter(ctx, m, view.fxs);
  }

  function vsSplash(ctx, m, k, t) {
    var e = FG.clamp(k, 0, 1);
    var slide = 1 - Math.min(1, e / 0.15);
    slide = slide * slide;
    var fade = Math.min(1, (1 - e) / 0.25);
    ctx.save();
    ctx.fillStyle = 'rgba(6,3,14,' + (0.78 * fade).toFixed(3) + ')';
    ctx.fillRect(0, 0, W, H);
    for (var i = 0; i < 2; i++) {
      var p = m.p[i], F = FG.FIGHTERS[p.fid], left = i === 0;
      ctx.save();
      ctx.globalAlpha = fade;
      ctx.translate(left ? -slide * 500 : slide * 500, 0);
      ctx.beginPath();
      if (left) { ctx.moveTo(0, 110); ctx.lineTo(W / 2 + 40, 110); ctx.lineTo(W / 2 - 40, 420); ctx.lineTo(0, 420); }
      else { ctx.moveTo(W, 110); ctx.lineTo(W / 2 + 40, 110); ctx.lineTo(W / 2 - 40, 420); ctx.lineTo(W, 420); }
      ctx.closePath();
      var g = ctx.createLinearGradient(0, 110, 0, 420);
      g.addColorStop(0, F.color);
      g.addColorStop(1, F.accent);
      ctx.fillStyle = g;
      ctx.fill();
      ctx.save();
      ctx.clip();
      var d = FG.sprites.def(p.fid, FG.sprites.DEFS[p.fid].select);
      var pose = { sx: 1.7, sy: 1.7 + Math.sin(t / 10) * 0.02, rot: 0, ox: 0, oy: 0 };
      FG.sprites.drawSprite(ctx, p.fid, d, left ? 220 : W - 220, 440, left ? 1 : -1, pose);
      ctx.restore();
      OT(ctx, F.name, left ? 40 : W - 40, 455, 40, '#ffffff', '#1a0630', 8, left ? 'left' : 'right');
      OT(ctx, '「' + F.quote + '」', left ? 40 : W - 40, 496, 20, '#ffe14d', '#000000', 5, left ? 'left' : 'right');
      ctx.restore();
    }
    ctx.globalAlpha = fade;
    var vs = e < 0.2 ? 2.2 - e * 6 : 1 + Math.sin(t / 5) * 0.03;
    ctx.translate(W / 2, 265);
    ctx.scale(vs, vs);
    OT(ctx, 'VS', 0, 0, 110, '#ffffff', '#c3001b', 12);
    ctx.restore();
  }

  function banner(ctx, m, view, t) {
    var S = view.fxs;
    if (m.phase === 'intro') {
      var pt = m.phaseT;
      var total = FG.INTRO_FRAMES + FG.VS_FRAMES;
      if (m.round === 1 && pt > 55) {
        vsSplash(ctx, m, (total - pt) / (total - 55), t);
      } else if (pt > 22) {
        var k = Math.min(1, (55 - pt) / 8);
        ctx.save();
        ctx.translate(W / 2, 240);
        ctx.scale(0.6 + 0.4 * k, 0.6 + 0.4 * k);
        OT(ctx, '第 ' + m.round + ' 回合', 0, 0, 64, '#ffffff', '#1a0630', 10);
        ctx.restore();
      } else {
        var k2 = 1 + (pt / 22) * 0.8;
        ctx.save();
        ctx.translate(W / 2, 240);
        ctx.scale(k2, k2);
        ctx.globalAlpha = Math.min(1, pt / 6 + 0.2);
        OT(ctx, 'FIGHT!', 0, 0, 84, '#ffe14d', '#7a1a00', 12);
        ctx.restore();
      }
    } else if (m.phase === 'ko') {
      var e = FG.KO_FRAMES - m.phaseT;
      if (e < 80) {
        var s = e < 10 ? 2.2 - e * 0.12 : 1 + Math.sin(e / 4) * 0.03;
        ctx.save();
        ctx.translate(W / 2, 230);
        ctx.scale(s, s);
        ctx.rotate(-0.05);
        OT(ctx, m.timer <= 0 ? 'TIME' : 'K.O.', 0, 0, 110, '#ff3b3b', '#ffffff', 10);
        if (S.perfect && e > 20) OT(ctx, 'PERFECT', 0, 80, 40, '#ffe14d', '#3a0a00', 8);
        ctx.restore();
      } else {
        var a = Math.min(1, m.phaseT / 30);
        var winText = m.winner === -2 ? '平局' : m.p[m.winner].name + ' 胜';
        ctx.save();
        ctx.globalAlpha = a;
        OT(ctx, winText, W / 2, 220, 60, '#ffffff', '#1a0630', 10);
        if (m.winner >= 0) OT(ctx, '「' + FG.FIGHTERS[m.p[m.winner].fid].winQuote + '」', W / 2, 284, 26, '#ffe14d', '#000000', 6);
        ctx.restore();
      }
    }
  }

  function fmtAdv(v) {
    if (v === null || v === undefined) return '—';
    return v > 0 ? '+' + v : String(v);
  }

  function trainingPanel(ctx, m, view) {
    var p = m.p[0];
    var id = p.lastMove;
    var mv = id ? p.moves[id] : null;
    var x = W / 2 - 300, y = 112;
    ctx.fillStyle = 'rgba(8,6,16,0.72)';
    rr(ctx, x, y, 600, 122, 10);
    ctx.fill();
    ctx.strokeStyle = 'rgba(127,208,255,0.4)';
    ctx.lineWidth = 1.5;
    ctx.stroke();
    var l1 = '上次招式：' + (mv ? mv.name + '（' + id + '）' : '—');
    var l2 = '';
    if (mv) {
      var kd = mv.hits.some(function (h) { return h.kd; });
      l2 = '启动 ' + mv.startup + ' · 持续 ' + mv.active + ' · 后摇 ' + mv.recovery + ' · 全长 ' + mv.frames;
      if (mv.hits.length) l2 += '　命中 ' + (kd ? '击倒' : fmtAdv(mv.advHit)) + ' · 防御 ' + fmtAdv(mv.advBlock);
    }
    var T = view.trk, R = T.rec;
    var advTxt = T.adv === null ? '—' : fmtAdv(T.adv) + '（' + T.advKind + (T.advMove ? ' · ' + T.advMove : '') + '）';
    var l2b = '实测帧优势 ' + advTxt + '　连段 ' + T.comboHits + ' Hit / ' + T.comboDmg +
      '　最高 ' + T.maxHits + ' Hit / ' + T.maxDmg;
    var recTxt = R.mode === 'rec' ? '● 录制中 ' + (R.buf.length / 60).toFixed(1) + 's（你在操控假人）' :
      (R.mode === 'play' ? '▶ 回放中 ' + (R.idx / 60).toFixed(1) + ' / ' + (R.buf.length / 60).toFixed(1) + 's' :
        (R.buf.length ? '已录 ' + (R.buf.length / 60).toFixed(1) + 's' : '未录制'));
    var l3 = '假人：' + (R.mode === 'off' ? FG.ai.DUMMY_NAMES[FG.ai.DUMMY_MODES[view.dummyMode]] : '录像') +
      '　判定框 ' + (view.showHitbox ? '开' : '关') + '　无限血 ' + (m.infinite ? '开' : '关') + '　录像：' + recTxt;
    var l4 = 'T 假人 · H 判定框 · R 重置 · I 无限血 · O 开始/停止录制假人 · P 回放录像';
    text(ctx, l1, x + 14, y + 17, 15, '#ffffff', 'left', 'bold');
    text(ctx, l2, x + 14, y + 39, 14, '#ffe9a8', 'left');
    text(ctx, l2b, x + 14, y + 61, 14, '#9be8ff', 'left', 'bold');
    text(ctx, l3, x + 14, y + 83, 13, R.mode === 'rec' ? '#ff9a9a' : '#d6c8ff', 'left');
    text(ctx, l4, x + 14, y + 105, 12, '#a99cc8', 'left');
  }

  // ---------------- 各界面 ----------------
  var IDLE_CAM = { x: 0, zoom: 1 };

  function menuButtons(ctx, items, index, cx, y, gap) {
    for (var i = 0; i < items.length; i++) {
      var sel = i === index;
      var w = sel ? 330 : 300, h = 44, x = cx - w / 2, yy = y + i * gap - h / 2;
      ctx.save();
      para(ctx, x, yy, w, h, 14);
      if (sel) {
        var g = ctx.createLinearGradient(x, 0, x + w, 0);
        g.addColorStop(0, '#ffe14d');
        g.addColorStop(1, '#ff8a00');
        ctx.fillStyle = g;
        ctx.shadowColor = 'rgba(255,190,40,0.7)';
        ctx.shadowBlur = 18;
      } else {
        ctx.fillStyle = 'rgba(20,10,36,0.8)';
      }
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.lineWidth = 2;
      ctx.strokeStyle = sel ? '#fff6c2' : 'rgba(255,255,255,0.25)';
      ctx.stroke();
      ctx.restore();
      if (sel) text(ctx, '▶ ' + items[i].label, cx + 7, y + i * gap, 22, '#2a0f00', 'center', '900');
      else text(ctx, items[i].label, cx + 7, y + i * gap, 20, 'rgba(255,255,255,0.88)', 'center', 'bold');
    }
  }

  function logo(ctx, x, y, t) {
    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(-0.04);
    var s = 1 + Math.sin(t / 20) * 0.015;
    ctx.scale(s, s);
    ctx.font = '900 76px ' + FONT;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.lineJoin = 'round';
    ctx.lineWidth = 16;
    ctx.strokeStyle = '#1a0630';
    ctx.strokeText('抽象格斗', 0, 0);
    var g = ctx.createLinearGradient(0, -38, 0, 38);
    g.addColorStop(0, '#fff6a8');
    g.addColorStop(0.5, '#ffd21f');
    g.addColorStop(1, '#ff7a00');
    ctx.fillStyle = g;
    ctx.fillText('抽象格斗', 0, 0);
    ctx.lineWidth = 2;
    ctx.strokeStyle = '#ffffff';
    ctx.strokeText('抽象格斗', 0, 0);
    ctx.restore();
    ctx.save();
    ctx.translate(x, y + 56);
    ctx.rotate(-0.04);
    para(ctx, -150, -15, 300, 30, 10);
    ctx.fillStyle = '#ff3b6b';
    ctx.fill();
    OT(ctx, '黄色三幻神 · 夜市乱斗', 4, 0, 18, '#ffffff', '#5a0020', 3);
    ctx.restore();
  }

  function drawTitle(ctx, view, t) {
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(10,4,22,0.45)';
    ctx.fillRect(0, 0, W, H);
    var bob = Math.sin(t / 12) * 4;
    FG.sprites.drawSprite(ctx, 'frog', 'win', 170, 530, 1,
      { sx: 1.55, sy: 1.55 + Math.sin(t / 9) * 0.03, rot: Math.sin(t / 30) * 0.04, ox: 0, oy: bob });
    FG.sprites.drawSprite(ctx, 'roo', 'win', W - 170, 530, -1,
      { sx: 1.6, sy: 1.6 + Math.sin(t / 11) * 0.02, rot: 0, ox: 0, oy: -bob });
    logo(ctx, W / 2, 110, t);
    menuButtons(ctx, view.items, view.index, W / 2, 262, 56);
    OT(ctx, '↑/↓ 选择 · Enter 确认 · 手柄 A 确认', W / 2, 508, 15, '#e5d8ff', '#120a1c', 4);
  }

  function statBar(ctx, label, v, x, y, color) {
    text(ctx, label, x, y, 14, '#ffffff', 'left', 'bold');
    for (var i = 0; i < 5; i++) {
      ctx.fillStyle = i < v ? color : 'rgba(255,255,255,0.16)';
      para(ctx, x + 44 + i * 24, y - 6, 20, 12, 4);
      ctx.fill();
    }
  }

  function drawSelect(ctx, view, t) {
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(10,4,22,0.6)';
    ctx.fillRect(0, 0, W, H);
    OT(ctx, '选择你的角色', W / 2, 44, 38, '#ffffff', '#1a0630', 8);
    OT(ctx, '模式：' + MODE_NAMES[view.mode], W / 2, 82, 16, '#ffd9ea', '#120a1c', 4);
    for (var i = 0; i < ORDER.length; i++) {
      var fid = ORDER[i], F = FG.FIGHTERS[fid];
      var cx = 250 + i * 460, sel = i === view.pick;
      var x0 = cx - 215, y0 = 104, w = 430, h = 380;
      ctx.save();
      rr(ctx, x0, y0, w, h, 18);
      var g = ctx.createLinearGradient(0, y0, 0, y0 + h);
      g.addColorStop(0, sel ? 'rgba(90,50,130,0.95)' : 'rgba(40,24,64,0.85)');
      g.addColorStop(1, sel ? 'rgba(40,18,70,0.95)' : 'rgba(20,10,36,0.9)');
      ctx.fillStyle = g;
      if (sel) { ctx.shadowColor = F.color; ctx.shadowBlur = 28; }
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.lineWidth = sel ? 4 : 2;
      ctx.strokeStyle = sel ? F.color : 'rgba(255,255,255,0.2)';
      ctx.stroke();
      ctx.clip();
      // 角色背后的色块光
      var glow = ctx.createRadialGradient(x0 + 115, y0 + h - 120, 10, x0 + 115, y0 + h - 120, 200);
      glow.addColorStop(0, F.color + (sel ? '88' : '33'));
      glow.addColorStop(1, F.color + '00');
      ctx.fillStyle = glow;
      ctx.fillRect(x0, y0, w, h);
      var bob = sel ? Math.abs(Math.sin(t / 8)) * 8 : 0;
      FG.sprites.drawSprite(ctx, fid, FG.sprites.DEFS[fid].select, x0 + 115, y0 + h - 34, 1,
        { sx: 1.45, sy: 1.45 + (sel ? Math.sin(t / 7) * 0.03 : 0), rot: 0, ox: 0, oy: bob });
      ctx.restore();
      var tx = x0 + 228;
      OT(ctx, F.name, tx, y0 + 40, 30, '#ffffff', '#1a0630', 7, 'left');
      text(ctx, F.tag, tx, y0 + 74, 14, F.color, 'left', 'bold');
      var sc = sel ? F.color : 'rgba(255,255,255,0.55)';
      statBar(ctx, '攻击', F.stats.atk, tx, y0 + 108, sc);
      statBar(ctx, '速度', F.stats.spd, tx, y0 + 134, sc);
      statBar(ctx, '体力', F.stats.hp, tx, y0 + 160, sc);
      statBar(ctx, '射程', F.stats.reach, tx, y0 + 186, sc);
      var sp = FG.MOVESETS[fid];
      var cells = ['236A', '623B', '214B', '214D'];
      for (var k = 0; k < cells.length; k++) {
        var cid = cells[k];
        text(ctx, cid.slice(0, 3) + '+' + cid[3] + ' ' + sp[cid].name, tx, y0 + 218 + k * 19, 12, '#ffe9a8', 'left', 'bold');
      }
      text(ctx, '236+C ' + sp['236C'].name, tx, y0 + 218 + 4 * 19, 12, '#ffb3c8', 'left', 'bold');
      OT(ctx, '「' + F.quote + '」', cx, y0 + h - 18, 17, '#ffe14d', '#000000', 4);
      if (sel) OT(ctx, view.mode === 'pvp' ? 'P1' : '你', x0 + 30, y0 + 28, 22, '#ffe14d', '#3a0a00', 5);
    }
    var other = FG.FIGHTERS[ORDER[1 - view.pick]].name;
    var tip = view.mode === 'pvp' ? 'P2 操控：' + other : (view.mode === 'training' ? '假人：' + other :
      (view.mode === 'arcade' ? '三关：' + other + ' → 暗黑' + FG.FIGHTERS[ORDER[view.pick]].name + ' → ' + other : '电脑对手：' + other));
    var hasDiff = view.mode === 'cpu';
    if (hasDiff) {
      var dn = FG.ai.LEVEL_NAMES[view.diff];
      ctx.save();
      ctx.fillStyle = 'rgba(14,9,28,0.85)';
      rr(ctx, W / 2 - 120, 488, 240, 30, 15);
      ctx.fill();
      ctx.restore();
      OT(ctx, '难度  ' + (view.diff > 1 ? '◀ ' : '　') + dn + (view.diff < 3 ? ' ▶' : '　') + '（↑/↓）', W / 2, 503, 15,
        ['', '#9be15d', '#ffd166', '#ff6b6b'][view.diff], '#120a1c', 4);
      OT(ctx, '←/→ 选择角色 · Enter 开始 · Esc 返回　　' + tip, W / 2, 530, 13, '#ffffff', '#120a1c', 4);
    } else {
      OT(ctx, '←/→ 选择角色 · Enter 开始 · Esc 返回　　' + tip, W / 2, 512, 15, '#ffffff', '#120a1c', 4);
    }
  }

  function drawFight(ctx, view, t) {
    var m = view.match, S = view.fxs, cam = view.cam;
    var sx = S.shake ? (Math.random() * 2 - 1) * S.shake : 0;
    var sy = S.shake ? (Math.random() * 2 - 1) * S.shake * 0.6 : 0;
    ctx.save();
    ctx.translate(sx * 0.4, sy * 0.4);
    FG.fx.stage(ctx, cam, t);
    ctx.restore();
    ctx.save();
    worldTransform(ctx, cam, sx, sy);
    drawWorld(ctx, view, t);
    ctx.restore();
    hud(ctx, m, view, t);
    if (view.mode === 'arcade' && view.arc) {
      OT(ctx, FG.arcade.STAGES[view.arc.stage].title + ' · ' + FG.ai.LEVEL_NAMES[FG.arcade.STAGES[view.arc.stage].level],
        W / 2, H - 24, 14, '#ffd9ea', '#120a1c', 4);
    }
    if (view.mode === 'training' && !S.superCut) trainingPanel(ctx, m, view);
    FG.fx.drawScreen(ctx, S, m, t);
    banner(ctx, m, view, t);
  }

  function panel(ctx, x, y, w, h) {
    ctx.fillStyle = 'rgba(14,9,28,0.92)';
    rr(ctx, x, y, w, h, 18);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,209,102,0.55)';
    ctx.lineWidth = 2;
    ctx.stroke();
  }

  function drawPause(ctx, view, t) {
    drawFight(ctx, view, t);
    ctx.fillStyle = 'rgba(8,6,16,0.6)';
    ctx.fillRect(0, 0, W, H);
    panel(ctx, W / 2 - 240, 140, 480, 330);
    OT(ctx, '暂停', W / 2, 190, 46, '#ffffff', '#1a0630', 8);
    menuButtons(ctx, view.items, view.index, W / 2, 268, 56);
    text(ctx, '↑/↓ 选择 · Enter 确认 · Esc 继续', W / 2, 444, 15, '#d6c8ff', 'center');
  }

  function drawResult(ctx, view, t) {
    var m = view.match;
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(8,4,16,0.62)';
    ctx.fillRect(0, 0, W, H);
    var wp = m.p[m.matchWinner], F = FG.FIGHTERS[wp.fid];
    var lp = m.p[1 - m.matchWinner];
    ctx.save();
    ctx.translate(250, 330);
    ctx.rotate(t * 0.004);
    for (var i = 0; i < 12; i++) {
      ctx.rotate(TAU / 12);
      ctx.fillStyle = 'rgba(255,220,90,0.10)';
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(600, -60); ctx.lineTo(600, 60); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    ctx.save();
    ctx.globalAlpha = 0.6;
    FG.sprites.drawSprite(ctx, lp.fid, FG.sprites.DEFS[lp.fid].down, 430, 528, -1,
      { sx: 1.1, sy: 1.1, rot: 0, ox: 0, oy: 0 });
    ctx.restore();
    FG.sprites.drawSprite(ctx, wp.fid, FG.sprites.DEFS[wp.fid].win, 250, 528, 1,
      { sx: 1.9, sy: 1.9 + Math.sin(t / 6) * 0.04, rot: Math.sin(t / 18) * 0.04, ox: 0, oy: Math.abs(Math.sin(t / 8)) * 10 });
    panel(ctx, W / 2 + 20, 110, 420, 320);
    OT(ctx, 'WINNER', W / 2 + 230, 150, 30, '#ffe14d', '#3a0a00', 6);
    OT(ctx, F.name, W / 2 + 230, 196, 44, '#ffffff', '#1a0630', 8);
    OT(ctx, '「' + F.winQuote + '」', W / 2 + 230, 244, 20, '#ffe14d', '#000000', 5);
    text(ctx, '比分  ' + m.wins[0] + ' : ' + m.wins[1], W / 2 + 230, 280, 20, '#ffffff', 'center', 'bold');
    menuButtons(ctx, view.items, view.index, W / 2 + 230, 334, 54);
  }

  function drawHelp(ctx, view, t) {
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(12,8,24,0.8)';
    ctx.fillRect(0, 0, W, H);
    OT(ctx, '操作说明', W / 2, 56, 38, '#ffffff', '#1a0630', 8);
    var lines = [
      'P1 移动：W 跳 · S 蹲 · A 左 · D 右',
      'P1 攻击：J 轻拳 A · K 重拳 B · L 轻脚 C · ; 重脚 D',
      'P2（本地双人）：方向键移动，N M , . 依次为 A B C D',
      '搓招方向按朝向换算（前 = 面向对手）',
      '奶蛙：236+A 舌鞭 · 623+B 大笑弹跳 · 236+C 齁齁齁连打（超杀）',
      '　　　214+B 肚皮压顶（跳压，须站防）· 214+D 躺平滑铲（下段）',
      '美团袋鼠：236+A 手铐飞扣 · 623+B 胆大上勾 · 236+C 胆子真是肥嘟嘟的',
      '　　　214+B 尾巴扫街（下段）· 214+D 准时飞踹（两段击倒）',
      '超必杀消耗 1 格能量（100）。防御：按住后方，站防挡中高段，蹲防挡下段',
      '系统：66 前冲 · 44 后撤（开头无敌）· 近身 B+D 投技（被抓瞬间同按 B+D 拆投）',
      '　　　防御中 C+D 防御反击（半格能量）· 被击倒瞬间按任意键受身',
      '手柄：左摇杆或十字键移动，A B X Y 对应 A B C D，Start 暂停',
      '训练：H 判定框 · T 假人 · R 重置 · I 无限血 · O 录制假人 · P 回放录像'
    ];
    for (var i = 0; i < lines.length; i++) text(ctx, lines[i], W / 2, 96 + i * 30, 15, '#e9e1ff', 'center');
    OT(ctx, 'Enter / Esc 返回标题', W / 2, 500, 18, '#ffd166', '#120a1c', 4);
  }

  // ---------------- 闯关界面 ----------------
  function wrapLines(ctx, str, maxW, size) {
    ctx.font = 'bold ' + size + 'px ' + FONT;
    var out = [], cur = '';
    for (var i = 0; i < str.length; i++) {
      var nx = cur + str[i];
      if (ctx.measureText(nx).width > maxW && cur) { out.push(cur); cur = str[i]; }
      else cur = nx;
    }
    if (cur) out.push(cur);
    return out;
  }

  function drawStory(ctx, view, t) {
    var A = view.arc, sm = FG.arcade.stageMatch(A.fid, A.stage);
    var lines = FG.arcade.LINES[A.fid][A.stage];
    var ln = lines[Math.min(A.line, lines.length - 1)];
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(8,4,16,0.55)';
    ctx.fillRect(0, 0, W, H);
    // 关卡标题
    ctx.save();
    ctx.translate(W / 2, 54);
    ctx.rotate(-0.03);
    para(ctx, -230, -24, 460, 48, 14);
    ctx.fillStyle = '#ff3b6b';
    ctx.fill();
    OT(ctx, sm.title, 4, 0, 26, '#ffffff', '#5a0020', 5);
    ctx.restore();
    OT(ctx, '难度 ' + FG.ai.LEVEL_NAMES[sm.level] + (A.continues ? '　已续关 ' + A.continues + ' 次' : ''), W / 2, 98, 15, '#ffd9ea', '#120a1c', 4);
    // 两名角色：说话的一方亮、放大
    var who = [A.fid, sm.fid1];
    for (var i = 0; i < 2; i++) {
      var speak = ln.s === i, left = i === 0;
      var pose = { sx: speak ? 1.75 : 1.6, sy: (speak ? 1.75 : 1.6) + (speak ? Math.sin(t / 7) * 0.03 : 0), rot: 0, ox: 0,
        oy: speak ? Math.abs(Math.sin(t / 9)) * 6 : 0, alpha: speak ? 1 : 0.55 };
      if (i === 1 && sm.mirror) pose.filter = DARK_FILTER;
      FG.sprites.drawSprite(ctx, who[i], speak ? 'idle' : 'block', left ? 190 : W - 190, 400, left ? 1 : -1, pose);
    }
    // 对话框
    var name = ln.s === 0 ? FG.FIGHTERS[A.fid].name : (sm.name1 || FG.FIGHTERS[sm.fid1].name);
    var col = ln.s === 0 ? FG.FIGHTERS[A.fid].color : (sm.mirror ? '#b48cff' : FG.FIGHTERS[sm.fid1].color);
    panel(ctx, 60, 388, W - 120, 124);
    ctx.save();
    para(ctx, ln.s === 0 ? 84 : W - 84 - 200, 372, 200, 34, 10);
    ctx.fillStyle = col;
    ctx.fill();
    ctx.restore();
    OT(ctx, name, ln.s === 0 ? 184 : W - 184, 389, 19, '#1a0630', '#ffffff', 4);
    var rows = wrapLines(ctx, ln.t, W - 200, 22);
    for (var r = 0; r < rows.length; r++) text(ctx, rows[r], W / 2, 438 + r * 32, 22, '#ffffff', 'center', 'bold');
    var blink = Math.floor(t / 20) % 2 ? '▼' : '▽';
    text(ctx, (A.line + 1) + ' / ' + lines.length + '　Enter 继续 ' + blink + '　Esc 放弃', W - 90, 496, 13, '#d6c8ff', 'right');
  }

  function drawContinue(ctx, view, t) {
    var A = view.arc;
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(8,4,16,0.75)';
    ctx.fillRect(0, 0, W, H);
    FG.sprites.drawSprite(ctx, A.fid, 'lying', 250, 470, 1, { sx: 1.8, sy: 1.8, rot: 0, ox: 0, oy: 0, alpha: 0.85 });
    panel(ctx, W / 2 + 10, 130, 400, 290);
    OT(ctx, '挑战失败', W / 2 + 210, 180, 42, '#ff6b6b', '#1a0630', 8);
    text(ctx, FG.arcade.STAGES[A.stage].title, W / 2 + 210, 224, 17, '#ffd9ea', 'center', 'bold');
    text(ctx, '已续关 ' + A.continues + ' 次', W / 2 + 210, 252, 15, '#d6c8ff', 'center');
    menuButtons(ctx, view.items, view.index, W / 2 + 210, 318, 56);
  }

  function drawEnding(ctx, view, t) {
    var A = view.arc, F = FG.FIGHTERS[A.fid];
    FG.fx.stage(ctx, IDLE_CAM, t);
    ctx.fillStyle = 'rgba(8,4,16,0.55)';
    ctx.fillRect(0, 0, W, H);
    ctx.save();
    ctx.translate(250, 330);
    ctx.rotate(t * 0.004);
    for (var i = 0; i < 12; i++) {
      ctx.rotate(TAU / 12);
      ctx.fillStyle = 'rgba(255,220,90,0.12)';
      ctx.beginPath(); ctx.moveTo(0, 0); ctx.lineTo(600, -60); ctx.lineTo(600, 60); ctx.closePath(); ctx.fill();
    }
    ctx.restore();
    FG.sprites.drawSprite(ctx, A.fid, 'win', 250, 520, 1,
      { sx: 1.9, sy: 1.9 + Math.sin(t / 6) * 0.04, rot: Math.sin(t / 18) * 0.04, ox: 0, oy: Math.abs(Math.sin(t / 8)) * 10 });
    panel(ctx, W / 2 - 10, 70, 450, 400);
    OT(ctx, '通关！', W / 2 + 215, 116, 48, '#ffe14d', '#3a0a00', 9);
    OT(ctx, F.name + ' · 结局', W / 2 + 215, 162, 22, '#ffffff', '#1a0630', 5);
    var E = FG.arcade.ENDINGS[A.fid];
    var shown = Math.min(E.length, Math.floor((t - (A.endTick || 0)) / 40) + 1);
    for (var k = 0; k < shown; k++) text(ctx, E[k], W / 2 + 215, 214 + k * 36, 18, '#ffe9a8', 'center', 'bold');
    text(ctx, '续关 ' + A.continues + ' 次', W / 2 + 215, 382, 15, '#d6c8ff', 'center');
    OT(ctx, 'Enter 返回标题', W / 2 + 215, 432, 18, '#ffd166', '#120a1c', 4);
  }

  function draw(ctx, view) {
    var t = view.tick;
    ctx.save();
    ctx.clearRect(0, 0, W, H);
    if (view.screen === 'title') drawTitle(ctx, view, t);
    else if (view.screen === 'select') drawSelect(ctx, view, t);
    else if (view.screen === 'fight' && view.match) drawFight(ctx, view, t);
    else if (view.screen === 'pause' && view.match) drawPause(ctx, view, t);
    else if (view.screen === 'result' && view.match) drawResult(ctx, view, t);
    else if (view.screen === 'help') drawHelp(ctx, view, t);
    else if (view.screen === 'story' && view.arc) drawStory(ctx, view, t);
    else if (view.screen === 'continue' && view.arc) drawContinue(ctx, view, t);
    else if (view.screen === 'ending' && view.arc) drawEnding(ctx, view, t);
    ctx.restore();
  }

  FG.render = { draw: draw, updateCamera: updateCamera };
})();
