/* 应用层：标题 / 选角 / 对战 / 暂停 / 结算 / 说明，以及固定 60Hz 的主循环。 */
(function () {
  'use strict';
  var FG = window.FG;
  var canvas = document.getElementById('game');
  var ctx = canvas.getContext('2d');
  // 高分屏按设备像素比放大画布，文字更清晰；逻辑坐标仍是 960x540
  var dpr = Math.min(2, window.devicePixelRatio || 1);
  canvas.width = FG.W * dpr;
  canvas.height = FG.H * dpr;
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  var ORDER = ['frog', 'roo'];

  var MODES = [
    { id: 'cpu', label: '单机 · 对战电脑' },
    { id: 'training', label: '训练模式' },
    { id: 'pvp', label: '本地双人' },
    { id: 'help', label: '操作说明' }
  ];
  var PAUSE_ITEMS = [{ label: '继续' }, { label: '重新开始' }, { label: '返回标题' }];
  var RESULT_ITEMS = [{ label: '再来一局' }, { label: '返回标题' }];

  var view = {
    screen: 'title', items: MODES, index: 0, tick: 0,
    mode: 'cpu', pick: 0, match: null, ai: null,
    showHitbox: false, dummyMode: 0, dummyState: FG.ai.newAI(1),
    lag: [1000, 1000], fxs: FG.fx.create(), cam: { x: 0, zoom: 1 }, slowAcc: 0
  };

  function setScreen(name) {
    view.screen = name;
    view.index = 0;
    if (name === 'fight') FG.input.clearTaps();   // 菜单里的按键不能带进对战
    if (name === 'title') view.items = MODES;
    else if (name === 'pause') view.items = PAUSE_ITEMS;
    else if (name === 'result') view.items = RESULT_ITEMS;
    else view.items = [];
  }

  function startMatch() {
    var p1 = ORDER[view.pick], p2 = ORDER[1 - view.pick];
    view.match = FG.sim.createMatch({ mode: view.mode, fid0: p1, fid1: p2, seed: Date.now() >>> 0 });
    view.ai = FG.ai.newAI(1);
    view.dummyState = FG.ai.newAI(1);
    view.lag = [view.match.p[0].health, view.match.p[1].health];
    view.fxs = FG.fx.create();
    view.cam = { x: 0, zoom: 1 };
    setScreen('fight');
  }

  function fightStep() {
    var m = view.match;
    var s = FG.input.sample();
    var p1 = s[0], p2 = s[1];
    if (view.mode === 'cpu') {
      p2 = FG.ai.cpuDecide(m, m.p[1], m.p[0], view.ai);
    } else if (view.mode === 'training') {
      p2 = FG.ai.dummyDecide(m, m.p[1], m.p[0], FG.ai.DUMMY_MODES[view.dummyMode], view.dummyState);
    }
    FG.sim.step(m, [p1, p2]);
    for (var i = 0; i < m.events.length; i++) {
      var e = m.events[i];
      FG.sfx.play(e.type === 'hit' && (e.heavy || e.kd) ? 'heavy' : e.type);
    }
    FG.fx.onEvents(view.fxs, m, m.events);
    if (m.phase === 'matchEnd') setScreen('result');
  }

  function handleActions() {
    var acts = FG.input.actions();
    if (!acts.length) return;
    FG.sfx.unlock();
    for (var i = 0; i < acts.length; i++) {
      var a = acts[i];
      if (view.screen === 'title') {
        if (a === 'up') view.index = (view.index + MODES.length - 1) % MODES.length;
        else if (a === 'down') view.index = (view.index + 1) % MODES.length;
        else if (a === 'ok') {
          var it = MODES[view.index];
          if (it.id === 'help') setScreen('help');
          else { view.mode = it.id; view.pick = 0; setScreen('select'); }
        }
      } else if (view.screen === 'select') {
        if (a === 'left' || a === 'right' || a === 'up' || a === 'down') view.pick = (view.pick + 1) % ORDER.length;
        else if (a === 'ok') startMatch();
        else if (a === 'back' || a === 'escape') setScreen('title');
      } else if (view.screen === 'fight') {
        if (a === 'escape') setScreen('pause');
        else if (a === 'hitbox') view.showHitbox = !view.showHitbox;
        else if (view.mode === 'training' && a === 'reset') FG.sim.resetRound(view.match);
        else if (view.mode === 'training' && a === 'dummy') view.dummyMode = (view.dummyMode + 1) % FG.ai.DUMMY_MODES.length;
        else if (view.mode === 'training' && a === 'infinite') view.match.infinite = !view.match.infinite;
      } else if (view.screen === 'pause') {
        if (a === 'up') view.index = (view.index + PAUSE_ITEMS.length - 1) % PAUSE_ITEMS.length;
        else if (a === 'down') view.index = (view.index + 1) % PAUSE_ITEMS.length;
        else if (a === 'ok') {
          if (view.index === 0) setScreen('fight');
          else if (view.index === 1) startMatch();
          else setScreen('title');
        } else if (a === 'escape' || a === 'back') setScreen('fight');
      } else if (view.screen === 'result') {
        if (a === 'up' || a === 'down') view.index = (view.index + 1) % RESULT_ITEMS.length;
        else if (a === 'ok') {
          if (view.index === 0) startMatch();
          else setScreen('title');
        } else if (a === 'escape' || a === 'back') setScreen('title');
      } else if (view.screen === 'help') {
        if (a === 'ok' || a === 'escape' || a === 'back') setScreen('title');
      }
    }
  }

  function updateFx() {
    if (view.screen === 'fight') {
      FG.fx.update(view.fxs, view.match, view.tick);
      FG.render.updateCamera(view.cam, view.match, view.fxs);
    }
    if (view.match) {
      for (var j = 0; j < 2; j++) {
        var hp = view.match.p[j].health;
        if (view.lag[j] > hp) view.lag[j] = Math.max(hp, view.lag[j] - 4);
        else view.lag[j] = hp;
      }
    }
  }

  var last = 0, acc = 0, STEP = 1 / 60;
  function frame(ts) {
    if (!last) last = ts;
    var dt = Math.min(0.1, (ts - last) / 1000);
    last = ts;
    view.tick++;
    handleActions();
    if (view.screen !== 'fight') FG.input.clearTaps();
    if (view.screen === 'fight') {
      acc += dt;
      while (acc >= STEP && view.screen === 'fight') {
        acc -= STEP;
        // KO 慢动作：只放慢表现节奏，逻辑帧本身不变
        if (view.fxs.slow > 0) {
          view.slowAcc = (view.slowAcc + 1) % 2;
          if (view.slowAcc) continue;
        }
        fightStep();
      }
      if (view.screen !== 'fight') acc = 0;
    } else {
      acc = 0;
    }
    updateFx();
    FG.render.draw(ctx, view);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
  FG.app = { view: view, startMatch: startMatch, setScreen: setScreen };
})();
