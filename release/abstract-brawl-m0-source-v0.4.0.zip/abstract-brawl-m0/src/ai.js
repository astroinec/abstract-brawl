/* 电脑陪练与训练假人：只输出按键掩码，与玩家走同一套规则（不作弊）。 */
(function () {
  'use strict';
  var FG = window.FG;
  var BIT = FG.BIT;

  var DUMMY_MODES = ['stand', 'crouch', 'auto', 'random'];
  var DUMMY_NAMES = { stand: '站立不动', crouch: '蹲下不动', auto: '自动防御', random: '随机防御' };

  function fwdOf(p) { return p.facing === 1 ? BIT.RIGHT : BIT.LEFT; }
  function backOf(p) { return p.facing === 1 ? BIT.LEFT : BIT.RIGHT; }

  function isLowAttack(o) {
    if (o.state !== 'atk' || !o.mv) return false;
    var hits = o.moves[o.mv].hits;
    for (var i = 0; i < hits.length; i++) if (hits[i].level === 'low') return true;
    return false;
  }

  // 搓招宏：每个元素是一帧的按键掩码
  function motionMasks(fwd, which, btn, back) {
    if (which === '236') return [BIT.DOWN, BIT.DOWN, BIT.DOWN | fwd, BIT.DOWN | fwd, fwd, fwd | btn];
    if (which === '214') return [BIT.DOWN, BIT.DOWN, BIT.DOWN | back, BIT.DOWN | back, back, back | btn];
    return [fwd, fwd, BIT.DOWN, BIT.DOWN, BIT.DOWN | fwd, BIT.DOWN | fwd | btn];
  }

  // 每次对方开始新动作只掷一次骰子，同一动作内答复不变；动作开始 3 帧后才生效，模拟反应时间
  function attackAnswer(m, opp, st, chance) {
    if (opp.state !== 'atk') return false;
    if (st.serial !== opp.serial) {
      st.serial = opp.serial;
      st.act = FG.nextRand(m) < chance;
    }
    return st.act && opp.mf >= 3;
  }

  function newAI(level) {
    var lv = level || 1;
    return { queue: [], think: 0, hold: 0, serial: -1, act: false, blockChance: lv >= 2 ? 0.8 : 0.5 };
  }

  function cpuDecide(m, me, opp, ai) {
    var fwd = fwdOf(me), back = backOf(me);
    var dist = Math.abs(opp.x - me.x) / FG.SUB;
    // 反应式防守：对方每出一招判定一次，判定通过则打断自己的动作后退防御（低段则蹲防）
    if (dist < 170 && attackAnswer(m, opp, ai, ai.blockChance)) {
      ai.queue = [];
      return back | (isLowAttack(opp) ? BIT.DOWN : 0);
    }
    if (ai.queue.length) return ai.queue.shift();
    if (ai.think > 0) { ai.think--; return ai.hold; }
    ai.think = 6 + Math.floor(FG.nextRand(m) * 12);
    if (dist > 150) { ai.hold = fwd; return fwd; }
    var r = FG.nextRand(m);
    if (r < 0.26) { ai.hold = 0; }
    else if (r < 0.42) { ai.hold = BIT.DOWN; }
    else if (r < 0.54) { ai.hold = back; }
    else if (r < 0.62) { ai.queue = [BIT.UP | fwd]; return ai.queue.shift(); }
    else if (r < 0.7 && me.power >= FG.SUPER_COST) { ai.queue = motionMasks(fwd, '236', BIT.C); return ai.queue.shift(); }
    else if (r < 0.8) { ai.queue = motionMasks(fwd, '236', BIT.A); return ai.queue.shift(); }
    else if (r < 0.86) { ai.queue = motionMasks(fwd, '623', BIT.B); return ai.queue.shift(); }
    else if (r < 0.9) { ai.queue = motionMasks(fwd, '214', BIT.B, back); return ai.queue.shift(); }
    else if (r < 0.94) { ai.queue = motionMasks(fwd, '214', BIT.D, back); return ai.queue.shift(); }
    else {
      var btns = [BIT.A, BIT.B, BIT.C, BIT.D];
      ai.queue = [btns[Math.floor(FG.nextRand(m) * 4)]];
      return ai.queue.shift();
    }
    return ai.hold;
  }

  function dummyDecide(m, me, opp, mode, st) {
    var blockBits = backOf(me) | (isLowAttack(opp) ? BIT.DOWN : 0);
    if (mode === 'auto') return opp.state === 'atk' ? blockBits : 0;
    if (mode === 'random') return attackAnswer(m, opp, st, 0.5) ? blockBits : 0;
    if (mode === 'crouch') return BIT.DOWN;
    return 0;
  }

  FG.ai = {
    newAI: newAI,
    cpuDecide: cpuDecide,
    dummyDecide: dummyDecide,
    DUMMY_MODES: DUMMY_MODES,
    DUMMY_NAMES: DUMMY_NAMES
  };
})();
