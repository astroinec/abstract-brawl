/* 自动化测试：在浏览器中运行，结果写入 window.__RESULT__ 与页面 #out。 */
(function () {
  'use strict';
  var FG = window.FG, BIT = FG.BIT, px = FG.px, SUB = FG.SUB;
  var F = BIT.RIGHT, B = BIT.LEFT, DN = BIT.DOWN, UP = BIT.UP;
  var rows = [];
  var fails = 0;

  function ok(name, cond, extra) {
    var pass = !!cond;
    if (!pass) fails++;
    rows.push({ name: name, pass: pass, extra: extra === undefined ? '' : String(extra) });
  }
  function run(name, fn) {
    try { fn(); } catch (e) { ok(name + '（抛出异常）', false, e && e.stack ? e.stack.split('\n')[0] : e); }
  }
  // 1P 奶蛙（面向右）、2P 美团袋鼠（面向左）；跳过开场直接进入战斗
  function mk(f0, f1) {
    var m = FG.sim.createMatch({ mode: 'pvp', fid0: f0 || 'frog', fid1: f1 || 'roo', seed: 1 });
    m.phase = 'fight';
    m.phaseT = 0;
    return m;
  }
  function steps(m, n, a, b) {
    for (var i = 0; i < n; i++) {
      var ma = typeof a === 'function' ? a(i) : (a || 0);
      var mb = typeof b === 'function' ? b(i) : (b || 0);
      FG.sim.step(m, [ma, mb]);
    }
  }
  function seq(m, masks, p2) {
    for (var i = 0; i < masks.length; i++) FG.sim.step(m, [masks[i], p2 || 0]);
  }

  run('确定性', function () {
    var a = FG.sim.createMatch({ mode: 'pvp', seed: 7 });
    var b = FG.sim.createMatch({ mode: 'pvp', seed: 7 });
    var rnd = { seed: 99 };
    var dirs = [0, BIT.LEFT, BIT.RIGHT, BIT.DOWN, BIT.DOWN | BIT.LEFT, BIT.DOWN | BIT.RIGHT, BIT.UP, BIT.UP | BIT.RIGHT];
    var btns = [BIT.A, BIT.B, BIT.C, BIT.D];
    var same = true, at = -1, atk = 0;
    for (var i = 0; i < 1500 && same; i++) {
      var x = dirs[Math.floor(FG.nextRand(rnd) * dirs.length)];
      if (FG.nextRand(rnd) < 0.1) x |= btns[Math.floor(FG.nextRand(rnd) * 4)];
      var y = dirs[Math.floor(FG.nextRand(rnd) * dirs.length)];
      if (FG.nextRand(rnd) < 0.1) y |= btns[Math.floor(FG.nextRand(rnd) * 4)];
      FG.sim.step(a, [x, y]);
      FG.sim.step(b, [x, y]);
      if (a.p[0].state === 'atk' || a.p[1].state === 'atk') atk++;
      if (FG.sim.key(a) !== FG.sim.key(b)) { same = false; at = i; }
    }
    ok('同输入两次运行 1500 帧逐帧一致', same, same ? '' : '差异于第 ' + at + ' 步');
    ok('测试序列确实包含出招（非空转）', atk > 100, atk);
  });

  run('帧数据：5A 与 2C', function () {
    var mv = FG.MOVESETS.frog['5A'];
    ok('5A 启动5 / 持续2 / 后摇8 / 全长14（启动=第一判定帧序号）',
      mv.startup === 5 && mv.active === 2 && mv.recovery === 8 && mv.frames === 14,
      [mv.startup, mv.active, mv.recovery, mv.frames].join('/'));
    ok('帧数据自洽：启动+持续+后摇-1 = 全长', mv.startup + mv.active + mv.recovery - 1 === mv.frames);
    ok('5A 命中 +3 / 防御 0', mv.advHit === 3 && mv.advBlock === 0, mv.advHit + ' / ' + mv.advBlock);
    var c = FG.MOVESETS.frog['2C'];
    ok('2C 命中 +4 / 防御 +1', c.advHit === 4 && c.advBlock === 1, c.advHit + ' / ' + c.advBlock);
  });

  // 实测帧优势：攻击方出招后，双方各自回到可行动状态的帧差，应与面板显示的数值一致
  function measureAdv(cmd, defHold) {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-50);
    m.p[1].x = px(0);
    FG.sim.step(m, [cmd, 0]);
    var hit = -1, atkFree = -1, defFree = -1;
    for (var i = 1; i < 80 && (atkFree < 0 || defFree < 0); i++) {
      FG.sim.step(m, [0, defHold]);
      var a = m.p[0], d = m.p[1];
      if (hit < 0 && a.connected) hit = i;
      if (hit < 0) continue;
      if (atkFree < 0 && a.state !== 'atk') atkFree = i;
      if (defFree < 0 && (d.state === 'stand' || d.state === 'crouch' || d.state === 'air')) defFree = i;
    }
    return { connected: hit >= 0, adv: defFree - atkFree };
  }

  run('帧优势：实测与面板显示一致（5A/2C，命中与防御）', function () {
    var cases = [
      { mv: '5A', cmd: BIT.A, def: 0, kind: 'hit' },
      { mv: '5A', cmd: BIT.A, def: BIT.RIGHT, kind: 'block' },
      { mv: '2C', cmd: BIT.DOWN | BIT.C, def: 0, kind: 'hit' },
      { mv: '2C', cmd: BIT.DOWN | BIT.C, def: BIT.DOWN | BIT.RIGHT, kind: 'block' }
    ];
    cases.forEach(function (c) {
      var r = measureAdv(c.cmd, c.def);
      var mv = FG.MOVESETS.frog[c.mv];
      var shown = c.kind === 'hit' ? mv.advHit : mv.advBlock;
      ok(c.mv + ' ' + c.kind + '：实测 ' + r.adv + ' / 面板 ' + shown, r.connected && r.adv === shown, r.adv + ' vs ' + shown);
    });
  });

  run('搓招：236+A 舌鞭', function () {
    var m = mk('frog', 'roo');
    m.p[1].x = px(300);
    seq(m, [DN, DN | F, F, F | BIT.A]);
    ok('236A 被识别', m.p[0].mv === '236A', m.p[0].mv);
  });

  run('搓招：顺序错误不触发 236', function () {
    var m = mk('frog', 'roo');
    m.p[1].x = px(300);
    seq(m, [F, F | DN, DN, DN | BIT.A]);
    ok('错误顺序不触发 236A', m.p[0].mv !== '236A', m.p[0].mv);
  });

  run('搓招：623+B 升龙（美团袋鼠）', function () {
    var m = mk('roo', 'frog');
    m.p[1].x = px(300);
    seq(m, [F, F, DN, DN | F, DN | F | BIT.B]);
    ok('623B 被识别', m.p[0].mv === '623B', m.p[0].mv);
    steps(m, 6);
    ok('升龙会离地', m.p[0].y > 0, (m.p[0].y / SUB).toFixed(1));
  });

  run('搓招：623 顺序错误不触发（落到普通重拳）', function () {
    var m = mk('roo', 'frog');
    m.p[1].x = px(300);
    seq(m, [DN, DN | F, F, F | BIT.B]);
    ok('2→3→6+B 不识别为升龙', m.p[0].mv === '5B', m.p[0].mv);
  });

  run('搓招：214+B / 214+D 两个角色都能识别', function () {
    ['frog', 'roo'].forEach(function (fid) {
      [['B', BIT.B], ['D', BIT.D]].forEach(function (k) {
        var m = mk(fid, fid === 'frog' ? 'roo' : 'frog');
        m.p[1].x = px(300);
        seq(m, [DN, DN | B, B, B | k[1]]);
        ok(fid + ' 214' + k[0] + ' 被识别', m.p[0].mv === '214' + k[0], m.p[0].mv);
      });
    });
    var w = mk('frog', 'roo');
    w.p[1].x = px(300);
    seq(w, [DN, DN | F, F, F | BIT.D]);
    ok('236+D 不误判为 214D', w.p[0].mv !== '214D', w.p[0].mv);
  });

  // 让 P1 在距离 dist 处发出 214 必杀，P2 全程按 defHold，返回 P2 首次受到的结果
  function special214(fid, btn, dist, defHold) {
    var m = mk(fid, fid === 'frog' ? 'roo' : 'frog');
    m.p[0].x = px(-dist / 2);
    m.p[1].x = px(dist / 2);
    seq(m, [DN, DN | B, B, B | btn], defHold);
    var res = null, maxY = 0;
    for (var i = 0; i < 60 && !res; i++) {
      FG.sim.step(m, [0, defHold]);
      maxY = Math.max(maxY, m.p[0].y);
      if (m.p[1].state === 'stun') res = m.p[1].blocked ? 'block' : 'hit';
    }
    return { res: res, maxY: maxY, m: m };
  }

  run('214 必杀：判定高低与位移', function () {
    var hb = BIT.RIGHT;   // P2 面向左，按右即后方
    var r1 = special214('frog', BIT.B, 160, hb | DN);
    ok('奶蛙肚皮压顶为中段跳压：蹲防挡不住', r1.res === 'hit', r1.res);
    ok('肚皮压顶会离地', r1.maxY > 0, (r1.maxY / SUB).toFixed(1));
    var r2 = special214('frog', BIT.B, 160, hb);
    ok('肚皮压顶可被站防', r2.res === 'block', r2.res);
    var r3 = special214('frog', BIT.D, 180, hb);
    ok('奶蛙躺平滑铲为下段：站防挡不住', r3.res === 'hit', r3.res);
    var r4 = special214('roo', BIT.B, 150, hb);
    ok('袋鼠尾巴扫街为下段：站防挡不住', r4.res === 'hit', r4.res);
    var r5 = special214('roo', BIT.B, 150, hb | DN);
    ok('尾巴扫街可被蹲防', r5.res === 'block', r5.res);
    var r6 = special214('roo', BIT.D, 170, 0);
    ok('袋鼠准时飞踹命中', r6.res === 'hit', r6.res);
    steps(r6.m, 60);
    ok('准时飞踹两段都命中并击倒', r6.m.p[0].lastResult === 'hit' && r6.m.p[1].health <= r6.m.p[1].maxHealth - 140, r6.m.p[1].maxHealth - r6.m.p[1].health);
  });

  run('214 必杀可由普通技取消', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-50); m.p[1].x = px(0);
    FG.sim.step(m, [BIT.A, 0]);
    steps(m, 7);
    ok('5A 已命中（214D 取消前提）', m.p[0].connected === true, m.p[0].connected);
    seq(m, [DN, DN | B, B, B | BIT.D]);
    steps(m, 2);
    ok('5A 命中后取消为 214D', m.p[0].mv === '214D', m.p[0].mv);
  });

  run('超必杀：能量不足不发，满 100 发出并扣能量', function () {
    var a = mk('roo', 'frog');
    a.p[1].x = px(300);
    a.p[0].power = 50;
    seq(a, [DN, DN | F, F, F | BIT.C]);
    steps(a, 2);
    ok('能量 50 时不发 236C', a.p[0].mv !== '236C', a.p[0].mv);
    var b = mk('roo', 'frog');
    b.p[1].x = px(300);
    b.p[0].power = 100;
    seq(b, [DN, DN | F, F, F | BIT.C]);
    steps(b, 2);
    ok('能量 100 时发 236C 并扣至 0', b.p[0].mv === '236C' && b.p[0].power === 0, b.p[0].mv + ' / ' + b.p[0].power);
  });

  run('命中：5A 造成 40 点伤害', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-60);
    m.p[1].x = px(0);
    var h0 = m.p[1].health;
    FG.sim.step(m, [BIT.A, 0]);
    steps(m, 8);
    ok('5A 命中扣 40', m.p[1].health === h0 - 40, h0 - m.p[1].health);
    ok('攻击方记录为命中', m.p[0].lastResult === 'hit', m.p[0].lastResult);
  });

  run('防御：按住后方挡中段，扣 1/10', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-60);
    m.p[1].x = px(0);
    var h0 = m.p[1].health;
    FG.sim.step(m, [BIT.A, BIT.RIGHT]);
    steps(m, 8, 0, BIT.RIGHT);
    ok('防住（攻击方结果为 block）', m.p[0].lastResult === 'block', m.p[0].lastResult);
    ok('防御掉 4 点（40 的 1/10）', m.p[1].health === h0 - 4, h0 - m.p[1].health);
  });

  run('高低：下段 2C 站防挡不住，蹲防可挡', function () {
    var a = mk('frog', 'roo');
    a.p[0].x = px(-50);
    a.p[1].x = px(0);
    FG.sim.step(a, [DN | BIT.C, 0]);
    steps(a, 8, 0, BIT.RIGHT);
    ok('站防挡不住下段', a.p[0].lastResult === 'hit', a.p[0].lastResult);
    var b = mk('frog', 'roo');
    b.p[0].x = px(-50);
    b.p[1].x = px(0);
    FG.sim.step(b, [DN | BIT.C, 0]);
    steps(b, 8, 0, DN | BIT.RIGHT);
    ok('蹲防可挡下段', b.p[0].lastResult === 'block', b.p[0].lastResult);
  });

  run('气弹：舌鞭命中扣 70', function () {
    var m = mk('frog', 'roo');
    m.p[1].x = px(250);
    seq(m, [DN, DN | F, F, F | BIT.A]);
    var h0 = m.p[1].health;
    steps(m, 150);
    ok('舌鞭命中扣 70', m.p[1].health === h0 - 70, h0 - m.p[1].health);
  });

  run('连段取消：5A 命中后可取消为舌鞭', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-50);
    m.p[1].x = px(0);
    FG.sim.step(m, [BIT.A, 0]);
    steps(m, 7);
    ok('5A 已命中（连段开始）', m.p[0].connected === true, m.p[0].connected);
    seq(m, [DN, DN | F, F, F | BIT.A]);
    steps(m, 2);
    ok('命中后取消为 236A', m.p[0].mv === '236A', m.p[0].mv);
  });

  run('跳跃：起跳有高度，落地回到站立', function () {
    var m = mk('frog', 'roo');
    FG.sim.step(m, [UP, 0]);
    var peak = 0;
    for (var i = 0; i < 60; i++) {
      FG.sim.step(m, [0, 0]);
      peak = Math.max(peak, m.p[0].y);
    }
    ok('起跳有高度（>50px）', peak > px(50), (peak / SUB).toFixed(1));
    ok('落地后站立', m.p[0].state === 'stand' && m.p[0].y === 0, m.p[0].state + ' / ' + m.p[0].y);
  });

  run('边界：不走出舞台', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-395);
    steps(m, 90, B, 0);
    ok('左墙限制在 -400px 以内', m.p[0].x >= px(-400), (m.p[0].x / SUB).toFixed(1));
  });

  run('推挤：重叠时自动分开', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = 0;
    m.p[1].x = px(10);
    FG.sim.step(m, [0, 0]);
    var gap = Math.abs(m.p[1].x - m.p[0].x);
    ok('间距不小于最小值', gap >= px(FG.PUSH_MIN) - 1, (gap / SUB).toFixed(1));
  });

  run('KO：血量归零判负并计入胜场', function () {
    var m = mk('frog', 'roo');
    m.p[0].x = px(-50);
    m.p[1].x = px(0);
    m.p[1].health = 30;
    FG.sim.step(m, [BIT.A, 0]);
    steps(m, 10);
    ok('进入 KO 阶段，红方（奶蛙）胜', m.phase === 'ko' && m.winner === 0, m.phase + ' / ' + m.winner);
    steps(m, FG.KO_FRAMES + 2);
    ok('结算后胜场 +1 并进入下一回合', m.wins[0] === 1 && m.phase === 'intro', m.wins.join('-') + ' / ' + m.phase);
  });

  run('训练假人：自动防御只在对方出招时防御', function () {
    var m = mk('frog', 'roo');
    ok('对方未出招 → 不动', FG.ai.dummyDecide(m, m.p[1], m.p[0], 'auto') === 0);
    m.p[0].state = 'atk';
    m.p[0].mv = '5A';
    var k1 = FG.ai.dummyDecide(m, m.p[1], m.p[0], 'auto');
    ok('对方中段出招 → 后退防御', k1 === BIT.RIGHT, k1);
    m.p[0].mv = '2C';
    var k2 = FG.ai.dummyDecide(m, m.p[1], m.p[0], 'auto');
    ok('对方下段出招 → 蹲下防御', k2 === (BIT.RIGHT | BIT.DOWN), k2);
  });

  run('随机防御假人：同一次攻击答复一致，多次攻击有防有不防', function () {
    var m = mk('frog', 'roo');
    var st = FG.ai.newAI(1);
    m.p[0].state = 'atk'; m.p[0].mv = '5A'; m.p[0].mf = 5; m.p[0].serial = 1;
    var first = FG.ai.dummyDecide(m, m.p[1], m.p[0], 'random', st);
    var same = true;
    for (var i = 0; i < 10; i++) if (FG.ai.dummyDecide(m, m.p[1], m.p[0], 'random', st) !== first) same = false;
    ok('同一次攻击内答复不变', same, first);
    var blocks = 0;
    for (var k = 0; k < 40; k++) {
      m.p[0].serial = 100 + k;
      if (FG.ai.dummyDecide(m, m.p[1], m.p[0], 'random', st) !== 0) blocks++;
    }
    ok('随机防御：40 次攻击中有防也有不防', blocks > 5 && blocks < 35, blocks);
  });

  run('数据：连段取消目标全部存在', function () {
    var missing = [];
    Object.keys(FG.MOVESETS).forEach(function (fid) {
      var set = FG.MOVESETS[fid];
      Object.keys(set).forEach(function (id) {
        set[id].cancels.forEach(function (c) { if (!set[c]) missing.push(fid + ':' + id + '->' + c); });
      });
    });
    ok('所有取消目标存在', missing.length === 0, missing.join(' '));
  });

  run('电脑陪练：3600 帧稳定运行', function () {
    var m = FG.sim.createMatch({ mode: 'cpu', fid0: 'frog', fid1: 'roo', seed: 5 });
    var ai = FG.ai.newAI(1), bad = '', starts = 0, last = [null, null];
    for (var i = 0; i < 3600 && !bad; i++) {
      var p2 = FG.ai.cpuDecide(m, m.p[1], m.p[0], ai);
      var p1 = (i % 90 < 45) ? F : ((i % 90 < 60) ? (DN | F | BIT.A) : 0);
      FG.sim.step(m, [p1, p2]);
      for (var j = 0; j < 2; j++) {
        var q = m.p[j];
        if (q.state === 'atk' && q.mv !== last[j]) starts++;
        last[j] = q.state === 'atk' ? q.mv : null;
        if (!isFinite(q.x) || !isFinite(q.y) || q.health < 0 || q.power < 0 || q.power > FG.POWER_MAX) {
          bad = '第 ' + i + ' 帧 P' + (j + 1) + ' 数值异常';
        }
      }
      if (m.phase === 'matchEnd') m = FG.sim.createMatch({ mode: 'cpu', fid0: 'frog', fid1: 'roo', seed: i + 1 });
    }
    ok('电脑陪练 3600 帧无异常', bad === '', bad);
    ok('电脑陪练确实出招（>10 次）', starts > 10, starts);
  });

  run('电脑对电脑：完整对局能结束，且有攻防', function () {
    var m = FG.sim.createMatch({ mode: 'cpu', fid0: 'frog', fid1: 'roo', seed: 11 });
    var a0 = FG.ai.newAI(2), a1 = FG.ai.newAI(2);
    var rounds = 0, contacts = 0, f = 0;
    for (f = 0; f < 60 * 60 * 15 && m.phase !== 'matchEnd'; f++) {
      var i0 = FG.ai.cpuDecide(m, m.p[0], m.p[1], a0);
      var i1 = FG.ai.cpuDecide(m, m.p[1], m.p[0], a1);
      FG.sim.step(m, [i0, i1]);
      for (var e = 0; e < m.events.length; e++) {
        if (m.events[e].type === 'ko') rounds++;
        if (m.events[e].type === 'hit' || m.events[e].type === 'block') contacts++;
      }
    }
    ok('电脑对电脑 15 分钟内打完整场', m.phase === 'matchEnd', 'frames=' + f + ' phase=' + m.phase);
    ok('电脑对电脑回合结束 ≥ 2 次', rounds >= 2, rounds);
    ok('电脑对电脑攻防接触 ≥ 20 次', contacts >= 20, contacts);
  });

  window.__RESULT__ = { pass: fails === 0, fails: fails, rows: rows };
  var out = document.getElementById('out');
  if (out) {
    var passed = rows.filter(function (r) { return r.pass; }).length;
    out.textContent = rows.map(function (r) {
      return (r.pass ? 'PASS ' : 'FAIL ') + r.name + (r.extra ? '  [' + r.extra + ']' : '');
    }).join('\n') + '\n---\n通过 ' + passed + ' / ' + rows.length;
  }
  document.body.setAttribute('data-done', '1');
})();
